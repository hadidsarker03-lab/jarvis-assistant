package com.example.assistant

import java.util.Calendar
import java.util.Locale

object BengaliText {

    private val digits = mapOf(
        '০' to '0', '১' to '1', '২' to '2', '৩' to '3', '৪' to '4',
        '৫' to '5', '৬' to '6', '৭' to '7', '৮' to '8', '৯' to '9'
    )

    // বড় শব্দ আগে, যাতে ভুল জায়গায় রিপ্লেস না হয়
    private val numberWords = listOf(
        "দুটো" to "2টা", "দুটা" to "2টা",
        "এগারো" to "11", "বারো" to "12",
        "দুই" to "2", "তিন" to "3", "চার" to "4",
        "পাঁচ" to "5", "পাচ" to "5", "ছয়" to "6", "সাত" to "7",
        "আট" to "8", "নয়" to "9", "দশ" to "10", "এক" to "1"
    )

    /** বাংলা সংখ্যা → ইংরেজি, ইউনিকোড কম্পোজিশন এক করা, lowercase */
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(digits[c] ?: c)
        return sb.toString()
            .replace("\u09A1\u09BC", "\u09DC")
            .replace("\u09A2\u09BC", "\u09DD")
            .replace("\u09AF\u09BC", "\u09DF")
            .replace("\u09C7\u09BE", "\u09CB")
            .replace("\u09C7\u09D7", "\u09CC")
            .lowercase(Locale.ROOT)
    }

    fun has(text: String, vararg keys: String): Boolean {
        val t = norm(text)
        return keys.any { t.contains(norm(it)) }
    }

    private fun replaceNumberWords(text: String): String {
        var s = text
        for ((w, d) in numberWords) s = s.replace(norm(w), d)
        return s
    }

    /** "সকাল সাতটা", "সাড়ে ছয়টা", "রাত ১০:৩০", "৭টা ১৫ মিনিট" → (ঘণ্টা 0-23, মিনিট) */
    fun parseTime(raw: String, now: Calendar = Calendar.getInstance()): Pair<Int, Int>? {
        var t = replaceNumberWords(norm(raw))

        val colon = Regex("(\\d{1,2})\\s*:\\s*(\\d{2})").find(t)
        val half = Regex(norm("সাড়ে") + "\\s*(\\d{1,2})").find(t)
        val quarter = Regex(norm("সোয়া") + "\\s*(\\d{1,2})").find(t)
        val minus = Regex(norm("পৌনে") + "\\s*(\\d{1,2})").find(t)

        val base: Int
        var minute = 0
        when {
            colon != null -> {
                base = colon.groupValues[1].toInt()
                minute = colon.groupValues[2].toInt()
            }
            half != null -> {
                base = half.groupValues[1].toInt()
                minute = 30
            }
            quarter != null -> {
                base = quarter.groupValues[1].toInt()
                minute = 15
            }
            minus != null -> {
                val h = minus.groupValues[1].toInt()
                base = if (h <= 1) 12 else h - 1
                minute = 45
            }
            else -> {
                val minMatch = Regex("(\\d{1,2})\\s*" + norm("মিনিট")).find(t)
                if (minMatch != null) {
                    minute = minMatch.groupValues[1].toInt()
                    t = t.removeRange(minMatch.range)
                }
                val hMatch = Regex("(\\d{1,2})").find(t) ?: return null
                base = hMatch.groupValues[1].toInt()
            }
        }
        if (base > 23 || minute > 59) return null

        var h = base
        if (h <= 12) {
            when {
                has(t, "ভোর", "সকাল") -> if (h == 12) h = 0
                has(t, "দুপুর") -> if (h in 1..6) h += 12
                has(t, "বিকাল", "বিকেল", "সন্ধ্যা", "সন্ধা") -> if (h < 12) h += 12
                has(t, "রাত") -> when {
                    h == 12 -> h = 0
                    h in 6..11 -> h += 12
                }
                else -> {
                    // সময়ের অংশ না বললে পরবর্তী যে সময়টা আসবে সেটা ধরা হবে
                    val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                    val am = (h % 12)
                    val pm = am + 12
                    h = when {
                        am * 60 + minute > nowMin -> am
                        pm * 60 + minute > nowMin -> pm
                        else -> am
                    }
                }
            }
        }
        return Pair(h, minute)
    }

    private fun periodName(h: Int): String = when (h) {
        in 4..5 -> "ভোর"
        in 6..11 -> "সকাল"
        in 12..14 -> "দুপুর"
        in 15..16 -> "বিকাল"
        in 17..18 -> "সন্ধ্যা"
        else -> "রাত"
    }

    fun speakableTime(h: Int, m: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        return if (m == 0) "${periodName(h)} ${h12}টা" else "${periodName(h)} ${h12}টা $m মিনিট"
    }
}

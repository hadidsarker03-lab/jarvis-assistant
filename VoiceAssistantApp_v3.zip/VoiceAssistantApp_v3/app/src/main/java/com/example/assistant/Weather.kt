package com.example.assistant

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Open-Meteo (ফ্রি, API key লাগে না) থেকে বর্তমান আবহাওয়া। ব্যাকগ্রাউন্ড থ্রেড থেকে ডাকতে হবে। */
object Weather {

    fun fetch(lat: Double, lon: Double): String? {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code&timezone=auto"
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        try {
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val cur = JSONObject(body).getJSONObject("current")
            val temp = cur.getDouble("temperature_2m").roundToInt()
            val code = cur.getInt("weather_code")
            return "এখন তাপমাত্রা $temp ডিগ্রি সেলসিয়াস, আকাশ ${describe(code)}"
        } finally {
            conn.disconnect()
        }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "পরিষ্কার"
        1, 2 -> "আংশিক মেঘলা"
        3 -> "মেঘলা"
        45, 48 -> "কুয়াশাচ্ছন্ন"
        in 51..57 -> "গুঁড়ি গুঁড়ি বৃষ্টি হচ্ছে"
        in 61..67 -> "বৃষ্টি হচ্ছে"
        in 71..77 -> "তুষারপাত হচ্ছে"
        in 80..82 -> "ভারী বর্ষণ হচ্ছে"
        in 95..99 -> "বজ্রসহ বৃষ্টি হচ্ছে"
        else -> "মিশ্র"
    }
}

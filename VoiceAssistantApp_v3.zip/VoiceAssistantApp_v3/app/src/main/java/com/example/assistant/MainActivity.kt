package com.example.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var permText: TextView
    private lateinit var toggleButton: MaterialButton
    private lateinit var batteryButton: MaterialButton

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            saveLocationIfPossible()
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(
                    this, "মাইক্রোফোন পারমিশন ছাড়া চলবে না (Settings → Apps → Jarvis → Permissions)",
                    Toast.LENGTH_LONG
                ).show()
                refresh()
            } else {
                checkOverlayThenStart()
            }
        }

    private val overlayLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            startAssistant()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        permText = findViewById(R.id.permText)
        toggleButton = findViewById(R.id.toggleButton)
        batteryButton = findViewById(R.id.batteryButton)

        toggleButton.setOnClickListener {
            if (AssistantBus.running) {
                stopService(Intent(this, AssistantService::class.java))
                AssistantBus.running = false
                AssistantBus.post("জার্ভিস বন্ধ আছে")
            } else {
                requestPermissionsAndStart()
            }
        }

        batteryButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    override fun onStart() {
        super.onStart()
        AssistantBus.onStatus = { refresh() }
        saveLocationIfPossible()
        refresh()
    }

    override fun onStop() {
        AssistantBus.onStatus = null
        super.onStop()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsAndStart() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val missing = needed.filter { !granted(it) }
        if (missing.isEmpty()) checkOverlayThenStart() else permLauncher.launch(missing.toTypedArray())
    }

    private fun checkOverlayThenStart() {
        if (Settings.canDrawOverlays(this)) {
            startAssistant()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("একটি অনুমতি দরকার")
            .setMessage(
                "স্ক্রিন বন্ধ বা অ্যাপ মিনিমাইজ থাকা অবস্থায় ইউটিউব, হোয়াটসঅ্যাপ, অ্যালার্ম ইত্যাদি খুলতে " +
                    "\"অন্য অ্যাপের উপরে দেখান\" অনুমতি লাগে। এটা না দিলে ফ্ল্যাশলাইট, সময় ও আবহাওয়া চলবে, " +
                    "কিন্তু অ্যাপ খোলা শুধু তখনই কাজ করবে যখন জার্ভিস স্ক্রিনে খোলা।"
            )
            .setPositiveButton("সেটিং খুলুন") { _, _ ->
                overlayLauncher.launch(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("এখন না") { _, _ -> startAssistant() }
            .show()
    }

    private fun startAssistant() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_START)
        )
        AssistantBus.post("শুরু হচ্ছে...")
    }

    /** আবহাওয়ার জন্য শেষ জানা লোকেশন সেভ (ব্যাকগ্রাউন্ডে লোকেশন পড়া যায় না, তাই এখানে রাখা) */
    private fun saveLocationIfPossible() {
        if (!granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val best = lm.getProviders(true)
                .mapNotNull { p ->
                    try {
                        lm.getLastKnownLocation(p)
                    } catch (e: SecurityException) {
                        null
                    }
                }
                .maxByOrNull { it.time } ?: return
            getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit()
                .putString("lat", best.latitude.toString())
                .putString("lon", best.longitude.toString())
                .apply()
        } catch (e: Exception) {
            // ঐচ্ছিক ফিচার, ব্যর্থ হলে ডিফল্ট (ঢাকা) ব্যবহার হবে
        }
    }

    private fun refresh() {
        val running = AssistantBus.running
        toggleButton.text = if (running) "বন্ধ করুন" else "শুরু করুন"
        statusText.text = AssistantBus.lastStatus

        fun mark(ok: Boolean) = if (ok) "✓" else "✗"
        val sb = StringBuilder()
        sb.append("${mark(granted(Manifest.permission.RECORD_AUDIO))} মাইক্রোফোন (বাধ্যতামূলক)\n")
        if (Build.VERSION.SDK_INT >= 33) {
            sb.append("${mark(granted(Manifest.permission.POST_NOTIFICATIONS))} নোটিফিকেশন (Android 13+)\n")
        }
        sb.append("${mark(Settings.canDrawOverlays(this))} অন্য অ্যাপের উপরে দেখান (ব্যাকগ্রাউন্ডে অ্যাপ খুলতে)\n")
        sb.append("${mark(granted(Manifest.permission.ACCESS_COARSE_LOCATION))} লোকেশন (আবহাওয়া, ঐচ্ছিক — না দিলে ঢাকা)")
        permText.text = sb.toString()
    }
}

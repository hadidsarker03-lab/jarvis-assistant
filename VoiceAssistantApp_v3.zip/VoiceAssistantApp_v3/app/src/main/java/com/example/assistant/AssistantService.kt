package com.example.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * ব্যাকগ্রাউন্ডে (Foreground Service, microphone টাইপ) ক্রমাগত শোনে।
 * TTS বলার সময় রিকগনাইজার থামিয়ে রাখে, যাতে নিজের কথা নিজে না শোনে।
 */
class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.example.assistant.START"
        const val ACTION_STOP = "com.example.assistant.STOP"
        private const val CHANNEL_ID = "jarvis_listening"
        private const val NOTIF_ID = 1001
        private val WAKE_WORDS = listOf(
            "jarvis", "জার্ভিস", "জারভিস", "জার্বিস", "জারবিস", "জার্ভিজ", "জারভিজ", "জার্ভিশ"
        )
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var active = false
    private var speaking = false
    private var stopAfterSpeech = false
    private var awaitUntil = 0L
    private var errorStreak = 0
    private lateinit var commands: CommandHandler

    private val listenRunnable = Runnable { beginListening() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startAsForeground()
        } catch (e: Exception) {
            AssistantBus.post("ব্যাকগ্রাউন্ড সার্ভিস শুরু করা যায়নি (মাইক্রোফোন পারমিশন দিন)")
            stopSelf()
            return START_NOT_STICKY
        }

        if (!active) {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                AssistantBus.post("এই ফোনে স্পিচ রিকগনিশন নেই — Google অ্যাপ আপডেট/ইনস্টল করুন")
                stopSelf()
                return START_NOT_STICKY
            }
            active = true
            AssistantBus.running = true
            commands = CommandHandler(this, ::speak) { stopAfterSpeech = true }
            tts = TextToSpeech(this, this)
            createRecognizer()
            AssistantBus.post("\"জার্ভিস\" বলে ডাকুন...")
            scheduleListen(500)
        }
        // সিস্টেম মেরে ফেললে নিজে থেকে আর চালু হবে না (Android 12+ ব্যাকগ্রাউন্ড FGS নিষেধ)
        return START_NOT_STICKY
    }

    // ---------- Foreground notification ----------
    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "জার্ভিস শুনছে", NotificationManager.IMPORTANCE_LOW)
        )
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("জার্ভিস চালু আছে")
            .setContentText("\"জার্ভিস\" বলে ডাকুন")
            .setContentIntent(openApp)
            .addAction(0, "বন্ধ করুন", stop)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Speech recognition ----------
    private fun createRecognizer() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
        }
    }

    private fun scheduleListen(delayMs: Long) {
        handler.removeCallbacks(listenRunnable)
        if (active && !speaking) handler.postDelayed(listenRunnable, delayMs)
    }

    private fun beginListening() {
        if (!active || speaking) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            createRecognizer()
            scheduleListen(1500)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (SystemClock.elapsedRealtime() < awaitUntil) AssistantBus.post("বলুন, শুনছি...")
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (!active) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    errorStreak = 0
                    scheduleListen(300)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.cancel()
                    scheduleListen(1200)
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    AssistantBus.post("মাইক্রোফোন পারমিশন নেই")
                    stopSelf()
                }
                else -> {
                    errorStreak++
                    if (error == SpeechRecognizer.ERROR_NETWORK ||
                        error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_SERVER
                    ) {
                        AssistantBus.post("বাংলা স্পিচ চিনতে ইন্টারনেট লাগে — সংযোগ চেক করুন")
                    }
                    if (errorStreak % 5 == 0) createRecognizer()
                    scheduleListen(minOf(1000L * errorStreak, 5000L))
                }
            }
        }

        override fun onResults(results: Bundle?) {
            errorStreak = 0
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            handleMatches(matches)
            if (!speaking) scheduleListen(250)
        }
    }

    private fun handleMatches(matches: List<String>) {
        if (matches.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        val awaiting = now < awaitUntil

        var action: String? = null
        for (m in matches) {
            val text = BengaliText.norm(m)
            val wake = WAKE_WORDS.map { BengaliText.norm(it) }.firstOrNull { text.contains(it) }
            if (wake != null) {
                action = text.replace(wake, " ").replace(Regex("\\s+"), " ").trim()
                break
            }
        }
        if (action == null && awaiting) action = BengaliText.norm(matches[0]).trim()

        if (action == null) {
            AssistantBus.post("শুনেছি: ${matches[0]}")
            return
        }

        awaitUntil = 0L
        if (action.isEmpty()) {
            awaitUntil = now + 8000
            speak("জি, বলুন")
        } else {
            AssistantBus.post("আপনি বলেছেন: $action")
            commands.handle(action)
            if (commands.pendingAlarm) awaitUntil = SystemClock.elapsedRealtime() + 10000
        }
    }

    // ---------- Text to speech ----------
    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            AssistantBus.post("টেক্সট-টু-স্পিচ চালু হয়নি")
            return
        }
        var r = t.setLanguage(Locale("bn", "BD"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(Locale("bn", "IN"))
        }
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            AssistantBus.post("বাংলা ভয়েস ইনস্টল নেই — Settings → Text-to-speech থেকে বাংলা ভয়েস নামান")
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { onSpeechFinished() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { onSpeechFinished() }
            }
        })
        ttsReady = true
    }

    private fun speak(text: String) {
        AssistantBus.post(text)
        val t = tts
        if (!ttsReady || t == null) {
            if (stopAfterSpeech) stopSelf()
            return
        }
        speaking = true
        handler.removeCallbacks(listenRunnable)
        recognizer?.cancel()
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-" + System.nanoTime())
        if (r != TextToSpeech.SUCCESS) onSpeechFinished()
    }

    private fun onSpeechFinished() {
        speaking = false
        if (stopAfterSpeech) {
            stopSelf()
            return
        }
        scheduleListen(400)
    }

    override fun onDestroy() {
        active = false
        AssistantBus.running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        if (::commands.isInitialized) commands.shutdown()
        AssistantBus.post("জার্ভিস বন্ধ আছে")
        super.onDestroy()
    }
}

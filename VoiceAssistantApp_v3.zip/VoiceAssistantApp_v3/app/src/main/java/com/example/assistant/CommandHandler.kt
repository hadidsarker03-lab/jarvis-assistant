package com.example.assistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import java.util.Calendar
import java.util.concurrent.Executors

/**
 * কমান্ড বোঝা ও কাজ করা। `say` সবসময় main thread-এ ডাকা হয়।
 * মনে রাখুন: ব্যাকগ্রাউন্ড থেকে অ্যাপ খুলতে "অন্য অ্যাপের উপরে দেখান" পারমিশন লাগে (Android 10+)।
 */
class CommandHandler(
    private val context: Context,
    private val say: (String) -> Unit,
    private val requestStop: () -> Unit
) {
    /** সময় না বুঝলে true — পরের কথাটা সময় হিসেবে নেওয়া হবে */
    var pendingAlarm = false
        private set

    private var torchOn = false
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private val leadingFillers = setOf(
        "এ", "মেসেজ", "মেসেজে", "বার্তা", "পাঠাও", "পাঠান", "লিখো", "লেখো",
        "করো", "খোলো", "ওপেন", "open", "send", "message", "বলো", "যে"
    ).map { BengaliText.norm(it) }.toSet()
    private val trailingFillers = setOf("পাঠাও", "পাঠান", "send")
        .map { BengaliText.norm(it) }.toSet()

    fun shutdown() {
        io.shutdownNow()
    }

    fun handle(rawAction: String) {
        val action = BengaliText.norm(rawAction).trim()

        if (pendingAlarm) {
            pendingAlarm = false
            setAlarm(action)
            return
        }

        fun has(vararg keys: String): Boolean = BengaliText.has(action, *keys)

        when {
            has("বিদায়", "বন্ধ হও", "বন্ধ হয়ে যাও", "stop assistant", "goodbye") -> {
                requestStop()
                say("ঠিক আছে, বিদায়")
            }
            has("লাইট", "টর্চ", "torch", "flashlight", "ফ্ল্যাশ") -> {
                val off = has("নেভা", "নিভা", "অফ", "off", "বন্ধ")
                val on = has("জ্বাল", "জ্বল", "জালা", "অন", "on", "চালু")
                val target = when {
                    off -> false
                    on -> true
                    else -> !torchOn
                }
                if (setTorch(target)) {
                    say(if (target) "ফ্ল্যাশলাইট অন করা হয়েছে" else "ফ্ল্যাশলাইট অফ করা হয়েছে")
                } else {
                    say("এই ফোনে ফ্ল্যাশলাইট চালানো যাচ্ছে না")
                }
            }
            has("অ্যালার্ম", "এলার্ম", "অ্যালারম", "এলারম", "আলার্ম", "alarm") -> setAlarm(action)
            has("whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটসএপ", "হোয়াটস অ্যাপ", "ওয়াটসঅ্যাপ") -> whatsapp(action)
            has("ইউটিউব", "youtube", "ইউ টিউব") -> {
                val ok = openApp("com.google.android.youtube") ||
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
                say(if (ok) "ইউটিউব ওপেন করা হচ্ছে" else "ইউটিউব খুলতে পারিনি")
            }
            has("গান", "music", "মিউজিক", "song") -> {
                val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
                say(if (launch(i)) "মিউজিক অ্যাপ ওপেন করা হচ্ছে" else "মিউজিক অ্যাপ পাওয়া যায়নি")
            }
            has("আবহাওয়া", "weather", "তাপমাত্রা") -> weather()
            has("সময়", "কয়টা বাজে", "কটা বাজে", "time") -> {
                val c = Calendar.getInstance()
                say("এখন সময় " + BengaliText.speakableTime(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)))
            }
            else -> say("কমান্ড বুঝতে পারিনি")
        }
    }

    // ---------- অ্যালার্ম ----------
    private fun setAlarm(text: String) {
        val t = BengaliText.parseTime(text)
        if (t == null) {
            pendingAlarm = true
            say("কয়টার জন্য অ্যালার্ম সেট করব?")
            return
        }
        val (h, m) = t
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, m)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        if (launch(i)) {
            say(BengaliText.speakableTime(h, m) + " এ অ্যালার্ম সেট করা হয়েছে")
        } else {
            say("অ্যালার্ম সেট করতে পারিনি")
        }
    }

    // ---------- হোয়াটসঅ্যাপ ----------
    private fun whatsapp(action: String) {
        val keys = listOf("whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটসএপ", "হোয়াটস অ্যাপ", "ওয়াটসঅ্যাপ")
            .map { BengaliText.norm(it) }
        val key = keys.first { action.contains(it) }
        val rest = action.substringAfter(key).trimStart { it == 'ে' || it.isWhitespace() }
        val msg = rest.split(Regex("\\s+"))
            .filter { it.isNotEmpty() }
            .dropWhile { it in leadingFillers }
            .dropLastWhile { it in trailingFillers }
            .joinToString(" ")

        val pkgs = listOf("com.whatsapp", "com.whatsapp.w4b")
        if (msg.isEmpty()) {
            val ok = pkgs.any { openApp(it) }
            say(if (ok) "হোয়াটসঅ্যাপ ওপেন করা হচ্ছে" else "হোয়াটসঅ্যাপ পাওয়া যায়নি")
        } else {
            val ok = pkgs.any { p ->
                launch(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    setPackage(p)
                    putExtra(Intent.EXTRA_TEXT, msg)
                })
            }
            say(if (ok) "মেসেজ লেখা হয়েছে, কাকে পাঠাবেন বেছে নিন" else "হোয়াটসঅ্যাপ পাওয়া যায়নি")
        }
    }

    // ---------- আবহাওয়া ----------
    private fun weather() {
        val prefs = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val lat = prefs.getString("lat", null)?.toDoubleOrNull() ?: 23.8103 // ডিফল্ট: ঢাকা
        val lon = prefs.getString("lon", null)?.toDoubleOrNull() ?: 90.4125
        io.execute {
            val msg = try {
                Weather.fetch(lat, lon)
            } catch (e: Exception) {
                null
            }
            main.post { say(msg ?: "আবহাওয়ার তথ্য আনতে পারিনি, ইন্টারনেট চেক করুন") }
        }
    }

    // ---------- ফ্ল্যাশলাইট ----------
    private fun setTorch(on: Boolean): Boolean {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return try {
            val id = cm.cameraIdList.firstOrNull { cid ->
                val c = cm.getCameraCharacteristics(cid)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return false
            cm.setTorchMode(id, on)
            torchOn = on
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- হেল্পার ----------
    private fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    private fun openApp(pkg: String): Boolean {
        val i = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return launch(i)
    }
}

package com.example.assistant

import android.os.Handler
import android.os.Looper

/** Service থেকে Activity-তে স্ট্যাটাস পাঠানোর সহজ ব্রিজ। */
object AssistantBus {
    @Volatile var running = false
    @Volatile var lastStatus = "জার্ভিস বন্ধ আছে"
    var onStatus: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    fun post(status: String) {
        lastStatus = status
        main.post { onStatus?.invoke() }
    }
}
